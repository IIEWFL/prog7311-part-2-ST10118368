/* *Note that this scrpit is to be excuted on Sql Server* */

/*Database Creation*/
DROP DATABASE IF EXISTS agri_energy;
CREATE DATABASE agri_energy;
USE agri_energy;


/*Table Creation*/
CREATE TABLE UserTypes(
	ID				UNIQUEIDENTIFIER			PRIMARY KEY	DEFAULT NEWID()		NOT NULL,
	Description		NVARCHAR(250)												NOT NULL,
    UNIQUE (Description)
);

CREATE TABLE ProductTypes(
	ID				UNIQUEIDENTIFIER			PRIMARY KEY	DEFAULT NEWID()		NOT NULL,
	Description		NVARCHAR(250)												NOT NULL,
    UNIQUE (Description)
);

CREATE TABLE Users(
	ID					UNIQUEIDENTIFIER		PRIMARY KEY	DEFAULT NEWID()			NOT NULL,
	Name				NVARCHAR(250)												NOT NULL,
	Email				NVARCHAR(250)												NOT NULL,
	PhoneNumber			NVARCHAR(250)												NOT NULL,
	Password			NVARCHAR(250)												NOT NULL,
	UserType			NVARCHAR(250)												NOT NULL
);

CREATE TABLE Products(
	ID					UNIQUEIDENTIFIER			PRIMARY KEY	DEFAULT NEWID()		NOT NULL,
	Name				NVARCHAR(250)												NOT NULL,
	Quantity			int															NOT NULL,
	Production_Date		Date														NOT NULL,
	Price				Decimal(38, 2)												NOT NULL,
	Category			NVARCHAR(250)												NOT NULL,
    FarmerID			NVARCHAR(250)									 			NOT NULL
);

/*INSERTION INTO TABLE*/
INSERT INTO UserTypes(ID, Description)
VALUES
	('2c22712b-6781-4458-a18c-6aab039a50c4', 'Admin'),
	('9945c15f-fe01-4610-b028-f9fc9a111144', 'Employee'),
	('63e68d18-9a62-4963-8004-16ef9319f95b', 'Farmer');
    
INSERT INTO ProductTypes(ID, Description)
VALUES
	('e7501c5e-6382-4a1c-836f-afab2e4bb107', 'Grain'),
	('9fd0496a-1d93-4430-8f60-65409bb83e24', 'Seed'),
    ('bdf57ad0-b294-4443-9959-76d46ea7df01', 'Fruit'),
	('24c0450c-e0b5-4a39-897b-28b446452748', 'Vegetable'),
    ('6101ab89-cc15-4ef6-88b4-3e214ddb980a', 'Dairy/Frozen'),
	('c8b8baf9-2520-445c-ab37-de67f20bb229', 'Material'),
    ('2f7faa17-3214-477b-8c3f-911b7bef9d11', 'Animal Feed'),
    ('0cc00b19-e685-4cb5-9cf5-1ae70f27f915', 'Pantry'),
    ('e265d117-b466-4178-8374-593c541408b0', 'Beverage'),
	('1f38c619-29b2-4401-b7a0-e5ce9255e96a', 'Bakery'),
	('d17af833-531e-42f2-9ce1-bfdb37903702', 'Meat');

INSERT INTO Users(ID, Name, Email, PhoneNumber, password, UserType)
VALUES
	('06bf0525-ec40-4604-8fb3-4ec15e5ffaa6', 'Admin', 'admin@agrienergy.com', 0123456789, 'admin', 'Admin'),
    ('1e31f364-0a83-4ff7-9f3b-03f4ce2798ae', 'MacFlou', 'macflou@mcfloupro.co.za', 0153696789, 'mac12345', 'Farmer'),
    ('c3ea8584-7b6d-492d-bb08-5909354aa08c', 'Roma Paru', 'romap@yahoo.co.za', 0823366799, 'rp12345', 'Farmer'),
    ('95aeb803-4c95-4921-9944-378c27a72fad', 'Mpho Maroba', 'mmpho@agrienergy.com', 0783692589, 'm12345m', 'Employee');
    
INSERT INTO Products(ID, Name, Quantity, Production_Date, Price, Category, FarmerID)
VALUES
	('9ed1130d-bb7b-4534-81a9-798695d74bcc', 'Red Apple', 50, '2024-10-05', 36.89, 'Fruit', '1e31f364-0a83-4ff7-9f3b-03f4ce2798ae'),
    ('89e5787b-4f4e-4eaa-9b26-a82686edbbe4', 'Low Fat Milk', 95, '2024-12-12', 48.75, 'Dairy/Frozen', 'c3ea8584-7b6d-492d-bb08-5909354aa08c'),
    ('1131a13f-10f6-43ec-943b-d45395a6b7ed', 'BlueBerry Muffin', 160, '2024-09-25', 15.99, 'Bakery', '1e31f364-0a83-4ff7-9f3b-03f4ce2798ae');

/*View Data*/
SELECT * FROM UserTypes;
SELECT * FROM ProductTypes;
SELECT * FROM Users;
SELECT * FROM Products;    

/*Drop Tables*/
/*DROP TABLE Products;
DROP TABLE Users;
DROP TABLE ProductTypes;
DROP TABLE UserTypes;*/
